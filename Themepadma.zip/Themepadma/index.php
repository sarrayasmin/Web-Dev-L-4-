<?php get_header();?>
<!-- menu part end -->

<!-- search part -->
<section class="container">
  <div class="row">
    <div class="col-sm-8"></div>
    <div class="col-sm-4">
      <form action="">
        <input type="text">
        <button>Search</button>
      </form>
    </div>
  </div>
</section>
<!-- search end -->
<!-- hero part start -->
<?php get_template_part('template-parts/cotents/hero');?>
<!-- hero part end -->
<!-- photo part start -->
<?php get_template_part('template-parts/cotents/photo');?>
<!-- photo part end -->
<!-- news part start -->
<section class="container news">
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  
<?php
$qry1=new WP_Query([
  'post_type'=>'post',
  'category_name'=>'slider'
]);
?>

<div class="carousel-inner">

<?php 
$x=0;
while($qry1->have_posts()){$qry1->the_post();
  $x++;
?>

    <div class="carousel-item <?=($x==1)?'active':''?>">
<?php the_title();?>

      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
<?php } ?>
    
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</section>
<!-- news part end -->
<?php get_footer();?>