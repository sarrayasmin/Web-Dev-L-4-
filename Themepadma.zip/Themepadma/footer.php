
<!-- footer part start -->
<footer class="container-fluid mb-5 footer_cont">
  <div class="row container">
    <div class="col-sm-6">
    
  <?php dynamic_sidebar('footerleft');?>

    </div>
    <div class="col-sm-6">
    <?php dynamic_sidebar('footerright');?>
    </div>
  </div>
  <div class="row container-fluid footer_bottom">
    <div class="col-sm-6">
    <?php dynamic_sidebar('footerbootomleft');?>
    </div>
    <div class="col-sm-6 text-end">
    <?php dynamic_sidebar('footerbootomright');?>
    </div>
  </div>
</footer>
<!-- footer part end -->


<?php wp_footer();?>
</body>
</html>