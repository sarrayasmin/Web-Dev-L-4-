<section class="container hero text-center">
  <div class="row">
  <?php dynamic_sidebar('herotitle');?>
  </div>
  <div class="row">

    <div class="col-sm-4">
    <div class="card h-100" style="width: 18rem;">
  <?php dynamic_sidebar('herocard1');?>
</div>
    </div>

    <div class="col-sm-4">
    <div class="card h-100" style="width: 18rem;">
  <?php dynamic_sidebar('herocard2');?>
</div>
    </div>

    <div class="col-sm-4">
    <div class="card h-100" style="width: 18rem;">
  <?php dynamic_sidebar('herocard3');?>
</div>
    </div>

  </div>
</section>