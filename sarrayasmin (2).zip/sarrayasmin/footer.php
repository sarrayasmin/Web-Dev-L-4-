<footer class="container-fluid footer_1">
    <div class="container">
    <div class="row ft">
        <?php dynamic_sidebar('ft');?>
    </div>
    <div class="row foot">
        <div class="col-sm-3">
        <?php dynamic_sidebar('foot1');?>
        </div>
        <div class="col-sm-3">
        <?php dynamic_sidebar('foot2');?>
        </div>
        <div class="col-sm-3">
        <?php dynamic_sidebar('foot3');?>
        </div>
        <div class="col-sm-3">
        <?php dynamic_sidebar('foot4');?>
        </div>
    </div>
    <div class="row fb">
    <?php dynamic_sidebar('fb');?>
    </div>
    </div>
</footer>


<?php wp_footer();?>
</body>
</html>