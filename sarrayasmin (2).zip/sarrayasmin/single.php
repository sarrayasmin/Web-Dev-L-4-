<?php get_header();?>


<div class="container">
    <div class="row">
        <div class="col-sm-8">
            <div class="bg-warning p-2 text-center">
            <?php the_title('<h1>','</h1>');?>
            </div>
                <div class="row">
                    <div class="col-sm-12 thumb mt-3">
                    <?php the_post_thumbnail();?> 
                    </div>
                    <div class="col-sm-12">
                        <div class="hero">
                        <?php the_content();?>
                        </div>
                    </div>
            </div>
        </div>
        <div class="col-sm-4">
            sidebar
        </div>
    </div>
</div>

<?php get_footer();?>
  

