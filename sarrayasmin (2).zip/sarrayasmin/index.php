<?php get_header();?>
<?php
while(have_posts()):the_post();
?>

<div class="container">
    <div class="row">
        <div class="col-sm-8">
            <div class="bg-warning p-2 text-center">
                   <a style="text-decoration: none;" href="<?php the_permalink();?>"> <?php the_title('<h1>','</h1>');?></a>
            </div>
                <div class="row">
                    <div class="col-sm-5 thumb">
                    <?php the_post_thumbnail();?> 
                    <!-- img bottom -->
                    <div class="row">
                        <div class="col-sm-4"><?php the_author();?></div>
                        <div class="col-sm-4"><?php the_time('D/m/y');?></div>
                        <div class="col-sm-4">3</div>
                    </div>
                    <!-- img bottom end -->
                    <a href="">Read More</a>
                    </div>
                    <div class="col-sm-7">
                        <div class="hero">
                        <?php the_excerpt();?>
                        </div>
                    </div>
            </div>
        </div>
        <div class="col-sm-4">
            sidebar
        </div>
    </div>
</div>
<?php endwhile; ?>
<?php get_footer();?>
  

