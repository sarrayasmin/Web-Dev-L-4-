<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );


add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );
add_theme_support( 'post-thumbnails' );


register_nav_menus(  array(
    'TP' => 'Primary'
) );



?>