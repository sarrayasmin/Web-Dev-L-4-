<?php get_header(); ?>

<div class="container">
  
        <div class="title">
        <a href="#"><?php the_parmalink(); ?><?php the_title(); ?></a>
        </div>
    <div class="div">
    <?php the_content(); ?>
    </div>
    
</div>


<?php get_footer(); ?>