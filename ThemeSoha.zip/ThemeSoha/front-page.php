<?php get_header(); ?>

<div class="container">
    <?php 
    while(have_posts()){the_post();
        ?>
        <div class="title">
        <?php the_title(); ?>
        </div>
    <div class="div">
    <?php the_content(); ?>
    </div>
    
</div>

<?php } ?>
<?php get_footer(); ?>