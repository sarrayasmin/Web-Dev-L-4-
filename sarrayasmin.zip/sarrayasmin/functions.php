<?php
/*
* Functions Template
* @Package Sarra

*/

/**
 * Proper way to enqueue scripts and styles.
 */

//  echo '<pre>';
//  print_r(get_template_directory_uri() . '/style.css');
//  wp_die();
function sarra_scripts() {
	wp_enqueue_style( 'style-css', get_stylesheet_uri() );
	wp_register_style( 'style-bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css',['style-css'] );
   
    wp_enqueue_style('style-css');
    wp_enqueue_style('style-bootstrap');
    
	wp_register_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );
} add_action( 'wp_enqueue_scripts', 'sarra_scripts' );

add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo', array(
    'height' => 480,
    'width'  => 720,
) );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'post-thumbnails', array( 'post' ) );          // Posts only
add_theme_support( 'post-thumbnails', array( 'page' ) );          // Pages only
add_theme_support( 'post-thumbnails', array( 'post', 'movie' ) ); // Posts and Movies


	
    if ( ! function_exists( 'sarra_register_nav_menu' ) ) {

        function sarra_register_nav_menu(){
            register_nav_menus( array(
                'primary_menu' => __( 'Primary Menu', 'padma' ),
                'footer_menu'  => __( 'Footer Menu', 'padma' ),
            ) );
        }
        add_action( 'after_setup_theme', 'sarra_register_nav_menu', 0 );
    }

    register_sidebar( array(
		'name'          => 'Search',
		'id'            => 'search',
		'before_widget' => '',
		'after_widget'  => '',
	
	) );
    register_sidebar( array(
		'name'          => 'FT',
		'id'            => 'ft',
		'before_widget' => '',
		'after_widget'  => '',
	
	) );
    register_sidebar( array(
		'name'          => 'Foot1',
		'id'            => 'foot1',
		'before_widget' => '',
		'after_widget'  => '',
	
	) );
    register_sidebar( array(
		'name'          => 'Foot2',
		'id'            => 'foot2',
		'before_widget' => '',
		'after_widget'  => '',
	
	) );
    register_sidebar( array(
		'name'          => 'Foot3',
		'id'            => 'foot3',
		'before_widget' => '',
		'after_widget'  => '',
	
	) );
    register_sidebar( array(
		'name'          => 'Foot4',
		'id'            => 'foot4',
		'before_widget' => '',
		'after_widget'  => '',
	
	) );
    register_sidebar( array(
		'name'          => 'Fb',
		'id'            => 'fb',
		'before_widget' => '',
		'after_widget'  => '',
	
	) );


?>