<?php get_header();?>
<!-- slider part start -->
<!-- <section class="container-fluid slider">
<div class="container">
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">


  <div class="carousel-inner">
            <?php
            $x=0;
            while(have_posts()):the_post();
                $x++;
            ?>

    <div class="carousel-item <?=($x==1)?'active':''?>">
    <?php the_post_thumbnail();?>
      
    </div>
    <?php endwhile; ?>
  </div>
  
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
</section> -->
<!-- slider part end -->

<?php
while(have_posts()):the_post();
?>

<div class="container">
    <div class="bg-warning p-2 text-center">
    <?php the_title('<h1>','</h1>');?>
    </div>
    <div class="hero">
    <?php the_content();?>
    </div>
</div>
<?php endwhile; ?>
<?php get_footer();?>