<?php get_header();?>
<?php
while(have_posts()):the_post();
?>

<div class="container">
    <div class="row">
        <div class="col-sm-8">
            <div class="bg-warning p-2 text-center">
                    <?php the_title('<h1>','</h1>');?>
            </div>
                <div class="row">
                    <div class="col-sm-6">
                    <!-- <?php the_post_thumbnail();?>  -->
                    </div>
                    <div class="col-sm-6">
                        <div class="hero">
                        <?php the_excerpt();?>
                        </div>
                    </div>
            </div>
        </div>
        <div class="col-sm-4">
            sidebar
        </div>
    </div>
</div>
<?php endwhile; ?>
<?php get_footer();?>
  

