<header class="container-fluid">
    <div class="row">
        <div class="col-sm-4">
            <?php the_custom_logo();?>
        </div>
       <div class="col-sm-4">
        <?php dynamic_sidebar('search');?>
       </div>
       <div class="col-sm-4">
       <nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      
    <?php
    wp_nav_menu([
        'theme_location'=>'primary_menu',
        'menu_class'=>'menu_1 navbar-nav'
    ]);
    ?>
      
    </div>
  </div>
</nav>
       </div>
</header>
